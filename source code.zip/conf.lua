function love.conf(t)
    t.window.title = "Simple Outer Space Game"
    t.window.fullscreen = true
    t.window.fullscreentype = "exclusive"
    t.window.width = 1366
    t.window.height = 768
    t.console = true
    t.modules.physics = false
    t.modules.touch = true
    love.filesystem.setIdentity("Simple Outer Space Game")
end