
function createSpriteAnimator(object,delay,loopable,animTable,startFrame,endFrame,soundEffect)
   local animator = {}
    animator.gameObject = object
    animator.delay = delay
    animator.timer = -0.1
    animator.loopable = loopable
    animator.animTable = animTable
    animator.startFrame = startFrame
    animator.endFrame = endFrame
    animator.currentFrame = startFrame
    animator.soundEffect = soundEffect
    animator.updateAnimator = function ()
        if animator.gameObject.animation then
            if animator.timer < 0 then
                if animator.currentFrame == animator.startFrame and animator.soundEffect then
                    animator.soundEffect:stop()
                    animator.soundEffect:play()
                end
                if animator.currentFrame < animator.endFrame then
                    animator.currentFrame = animator.currentFrame + 1
                    animator.gameObject.image = animator.animTable[animator.currentFrame]
                else
                    if loopable then
                        animator.currentFrame = animator.startFrame
                        animator.gameObject.image = animator.animTable[animator.currentFrame]
                    else
                        animator.gameObject.animation = false
                    end
                end
                animator.timer = animator.delay
            else
                animator.timer = animator.timer - love.timer.getDelta()
            end
        end
    end
    animator.play = function (startIndex,endIndex)
        animator.startFrame = startIndex
        animator.currentFrame = startIndex
        animator.endFrame = endIndex
        animator.gameObject.image = animator.animTable[animator.currentFrame]
        animator.gameObject.animation = true
    end

    return animator
end

function createScalingAnimator(object,scaleToMax,minScaleX,minScaleY,maxScaleX,maxScaleY,speed)
    local animator = {}
    animator.gameObject = object
    animator.scaleToMax = scaleToMax
    animator.minScaleX = minScaleX
    animator.minScaleY = minScaleY
    animator.maxScaleX = maxScaleX
    animator.maxScaleY = maxScaleY
    animator.speed = speed
    
    animator.updateAnimator = function ()
        if not animator.scaleToMax then
            if animator.gameObject.scaleX > animator.minScaleX then
                animator.gameObject.scaleX = animator.gameObject.scaleX - animator.speed
            end
            if animator.gameObject.scaleY > animator.minScaleY then
                animator.gameObject.scaleY = animator.gameObject.scaleY - animator.speed
            end
            if animator.gameObject.scaleX <= animator.minScaleX and animator.gameObject.scaleY <= animator.minScaleY then
                animator.scaleToMax = true
            end
        else
            if animator.gameObject.scaleX < animator.maxScaleX then
                animator.gameObject.scaleX = animator.gameObject.scaleX + animator.speed
            end
            if animator.gameObject.scaleY < animator.maxScaleY then
                animator.gameObject.scaleY = animator.gameObject.scaleY + animator.speed
            end
            if animator.gameObject.scaleX >= animator.maxScaleX and animator.gameObject.scaleY >= animator.maxScaleY then
                animator.scaleToMax = false
            end
        end
            
    end

    return animator
end