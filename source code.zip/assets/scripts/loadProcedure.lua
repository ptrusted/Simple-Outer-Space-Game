
function loadImages ( ... )
    -- splash scene
    ImagesSplash = loadSpritesAnimImages('assets/sprites/splash/%d.png',1,31)
    -- game scene
    ImageTitle = love.graphics.newImage("assets/sprites/title.png")
    ImageDirection = love.graphics.newImage("assets/sprites/Direction.png")
    ImageShip = love.graphics.newImage("assets/sprites/the star ship.png")
    ImageBeam = love.graphics.newImage("assets/sprites/the beam.png")
    ImageEnemy1 = love.graphics.newImage("assets/sprites/enemy 1.png")
    ImageEnemy2 = love.graphics.newImage("assets/sprites/enemy 2.png")
    ImageEnemy3 = love.graphics.newImage("assets/sprites/enemy 3.png")
    ImagePlayButton = love.graphics.newImage("assets/sprites/play button.png")
    ImagesGameOver = loadSpritesAnimImages('assets/sprites/game over %d.png',1,4)
    ImagesExplosion = loadSpritesAnimImages('assets/sprites/explosion/%d.png',1,11)
end

function loadSounds ( ... )
	BgSoundMainMenu = love.audio.newSource('assets/sounds/Theme song 1.mp3','stream')
	BgSoundMainMenu:setLooping(true)
    BgSoundMainMenu:setVolume(1)
    BgSoundGamePlay = love.audio.newSource('assets/sounds/Theme song 2.mp3','stream')
	BgSoundGamePlay:setLooping(true)
    BgSoundGamePlay:setVolume(0.6)
    SfxBeam = love.audio.newSource('assets/sounds/Shot the beam.mp3','static') -- 'static' used for sfx
	SfxBeam:setLooping(false)
    SfxBeam:setVolume(1)
    SfxEnemy = love.audio.newSource('assets/sounds/Enemy destroyed.mp3','static') -- 'static' used for sfx
	SfxEnemy:setLooping(false)
    SfxEnemy:setVolume(1)
    SfxGameOver = love.audio.newSource('assets/sounds/Game over.mp3','static') -- 'static' used for sfx
	SfxGameOver:setLooping(false)
    SfxGameOver:setVolume(1)
    SfxSpeedUp = love.audio.newSource('assets/sounds/Speed up.mp3','static') -- 'static' used for sfx
	SfxSpeedUp:setLooping(false)
    SfxSpeedUp:setVolume(0.3)
end

function loadFonts ( ... )
    FontCalibri = love.graphics.newFont("assets/fonts/calibriz.ttf",14)
    love.graphics.setFont (FontCalibri)

    -- messages to player printed in console
    print(' \n\n Thanks for playing the game,\n in pc version you can use (w), (A), (S), and (D) keys to move \n press (enter) to start the game')
    --
end

function createGlobalVariables ()
    Scenes = {SplashScene, GameScene}
    CounterSelectedScene = 1
    CounterTimer = 0
    GlobalTimeSpan = 0
    Highscore = {}
    for i=1,10 do
        Highscore[i] = 0
    end
    -- ----------------------------------------------------------------- shader effects
    DefaultShader = love.graphics.getShader()
    ShaderEffects = {} -- table contains all shader
    ShaderEffects[1] = love.graphics.newShader [[
            //uniform vec4 colorScheme;
            uniform number time;
            uniform vec2 screenRes;
            vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords)
            {
                vec4 color_ = color;
                float temp1 = screen_coords.y/screenRes.y - abs(sin(time*3));
                float temp2 = screen_coords.x/screenRes.x - abs(cos(time*3));
                if (0.004 < temp1 && temp1 < 0.005) {
                    color_ = color + vec4(0.7,0.7,0.7,0.05);
                } else if (0.004 < temp1-0.2 && temp1-0.2 < 0.005) {
                    color_ = color + vec4(0.5,0.5,0.5,0.05);
                } else if (0.004 < temp1+0.2 && temp1+0.2 < 0.005) {
                    color_ = color + vec4(0.5,0.5,0.5,0.05);
                }

                if (0.004 < temp2 && temp2 < 0.005) {
                    color_ = color + vec4(0.7,0.7,0.7,0.05);
                } else if (0.004 < temp2-0.2 && temp2-0.2 < 0.005) {
                    color_ = color + vec4(0.5,0.5,0.5,0.05);
                } else if (0.004 < temp2+0.2 && temp2+0.2 < 0.005) {
                    color_ = color + vec4(0.5,0.5,0.5,0.05);
                }
                
                return color_ * texture2D(texture,texture_coords);
            }
        ]]
    ShaderEffects[1]:send("screenRes",{love.graphics.getWidth(),love.graphics.getHeight()})
    ShaderEffects[2] = love.graphics.newShader [[
        uniform number time;
        uniform vec2 screenRes;
        uniform vec2 playerPos;
        vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 pixel_coords)
        {
            float distanceToPlayer = distance(pixel_coords,playerPos);
            float distanceToCenter = distance(pixel_coords,screenRes/2);
            float playerGlowRadius = 100;
            float r,g,b,a = 1.0;
            vec4 color_ = vec4(1.0,1.0,1.0,1.0);
            if (distanceToPlayer < playerGlowRadius ) {
                r = abs(sin(time));
                g = 1-r;
                b = g;
                a = 1;
                color_ = color + (vec4(r,g,b,a) * (1 - distanceToPlayer/playerGlowRadius));
            } else if (distanceToCenter < screenRes.y/2) {
                color_ = color;
            } else {
                b = abs(cos(time));
                r = b/2;
                g = r;
                a = 1;
                color_ = color + (vec4(r,g,b,a) * (distanceToCenter/(screenRes.y/2) - 1));
            }
            return color_ * texture2D(texture, texture_coords);
        }
    ]]
    ShaderEffects[2]:send("screenRes",{love.graphics.getWidth(),love.graphics.getHeight()})
    CurrentShaderEffect = 0
    -- -----------------------------------------------------------------
    
    loadSavedVariables()
end

-- ---------------------------------------------------------------------------- other functions

function loadSavedVariables ()
    -- if the file doesn't exist, we should create it first
    local exist = love.filesystem.exists('Highscore.txt')
    --print(love.filesystem.getSaveDirectory() .. '/progress.txt')
    if exist then
        -- read it all the way and pass it to proper global variables
        local extractedData = extractDataFromFile ('Highscore.txt','###') 
        compareExtractedDataWithGlobalVariable(Highscore,extractedData)
    else
        -- create file
        saveProgress()
    end
end

function loadSpritesAnimImages (nameFormat,startIndex,finishIndex)
    local theImages = {}
	for i=startIndex,finishIndex do
		theImages[i] = love.graphics.newImage(string.format(nameFormat,i))
	end

    return theImages
end

function saveProgress ()
    local FileToSave = love.filesystem.newFile('Highscore.txt') 
    FileToSave:open('w')

    local dataToSave = ''
    for a,b in ipairs(Highscore) do
        dataToSave = dataToSave .. b .. '###'
    end

    FileToSave:write(dataToSave)
    FileToSave:close()
end

function extractDataFromFile (fileName,parser)
    local savedData = love.filesystem.read(fileName) -- we got the data
    local extractedData = {} -- this is where we store the extracted data
    local dataCounter = 1
    local startIndex,endIndex = string.find(savedData,parser) -- startIndex is where we begin the search until the parser found
    local tempIndex = 1 -- extra variable needed
    while startIndex do
        extractedData[dataCounter] = string.sub(savedData,tempIndex,startIndex-1)
        dataCounter = dataCounter + 1
        tempIndex = endIndex + 1
        startIndex,endIndex = string.find(savedData,parser,tempIndex)
    end
    
    return extractedData
end

function compareExtractedDataWithGlobalVariable (globalVariable,extractedData)
    if #globalVariable == #extractedData then
        for i=1,#globalVariable do
            globalVariable[i] = tonumber(extractedData[i])
        end
        return true
    else
        for i=1,#globalVariable do
            globalVariable[i] = 0
        end
        return false
    end
end